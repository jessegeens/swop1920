package model.Actions;

public class GameEndAction implements Action {
    @Override
    public void undo() {

    }

    @Override
    public void redo() {

    }
}
