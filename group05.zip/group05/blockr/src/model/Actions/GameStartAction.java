package model.Actions;

public class GameStartAction implements Action{

    @Override
    public void undo(){

    }

    @Override
    public void redo() {

    }


}
