package utilities;

public enum ConnectionPoint {
    TOP_SOCKET, BOTTOM_PLUG, RIGHT_SOCKET, LEFT_PLUG, CAVITY_SOCKET, CAVITY_PLUG;
}