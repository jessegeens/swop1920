package jumpergame;

import gameworldapi.ActionType;

public enum Action implements ActionType {
    JUMP, MOVE_LEFT, MOVE_RIGHT;
}
