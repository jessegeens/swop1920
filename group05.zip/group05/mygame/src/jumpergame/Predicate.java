package jumpergame;

import gameworldapi.PredicateType;

public enum Predicate implements PredicateType {
    BLOCK_ABOVE;
}
