package robotgameworld;

import gameworldapi.*;
public enum Action implements ActionType {
    MOVE_FORWARD, TURN_LEFT, TURN_RIGHT;
}
