package robotgameworld;

import gameworldapi.*;
public enum Predicate implements PredicateType {
    //Only WALL_IN_FRONT, if you also add NOT_WALL_IN_FRONT it would have its own block
    WALL_IN_FRONT;

}
