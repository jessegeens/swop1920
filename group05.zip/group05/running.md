# Running the Blockr application
## Running from JAR
To run the blockr application from a jar, navigate to the correct directory
in your terminal and execute the following command:

> java -classpath "gameworldapi.jar;robotgameworld.jar;blockr.jar" 
> -cp blockr.jar main.Main  robotgameworld.jar/robotgameworld.RobotGameWorldType

Replace `robotgameworld.jar` with `jumpergame.jar` and 
`robotgameworld.RobotGameWorldType` with `jumpergame.JumperGameWorldType` to
load our simplegame.

Replace `blockr.jar main.Main` with `simplgameeapp main.Main` 
to run the simplegameapp.

## Running in your IDE
The Blockr application expects one argument, in the form of:

The path of the class file, excluding the package, followed with a `/`,
followed with the class file, in the format of `package.ClassName`

You can paste this argument as the argument in the run configuration.

For example:

> /home/jesse/project/gameworld/out/production/gameworld/gameworld.GameWorldType 
